/* Project Header
 * 
 * Websites Used:
 * https://stackoverflow.com/questions/1655294/java-swing-multiple-windows?noredirect=1&lq=1
 * https://stackoverflow.com/questions/271526/avoiding-nullpointerexception-in-java?rq=1
 * https://stackoverflow.com/questions/26305/how-can-i-play-sound-in-java
 * 
 * Name: Lukas Bozinov
 * 
 * Date: June 8, 2021
 * 
 * Course Code: ICS-3U1
 * 
 * Title: "Pac-Man" by Lukas Bozinov
 * 
 * Description: This project creates a new and improved version of the arcade classic "Pac-Man" complete with
 * custom levels, new textures and block placements, as well as new effects and powerups, while still keeping the overall feel of the classic game.
 * The game is divided into 9 different classes. PacManGUI() runs our GUi for the game. Board() creates our map and sets up audio, images, and
 * events. Ghost() creates our ghost Icons, and Pacman() our pacman animation Icons. Mover() has all the makings of a template class but also has 
 * abstract class elements to it that allow it to make pacman move. MapSelection() and MapSelectionTemplate() go hand in hand, as they both display
 * a menu for which map a user would want to play.
 * 
 *
 * Major Skills: Arrays, Swing GUI components, javax.sound components, Scanner, java.io, and java.awt / java.awt.event components are used in this project.
 * 
 * Added Features:
 * 
 * COMPLETED ENHANCEMENTS
 * - Added cherries that give bonus points when collected
 * - Added three new maps to add to the original one, with a selection screen for the user
 * - Added sound effects for different actions, like pellets, an introduction theme, a theme for winning,
	 cherry pickups, and death noises
 * - The fourth map has a speed modifier for the ghosts and for pac man
 * - Displays current score
 * - Map 2 (Special Mode) has a special mode! You can either kill a ghost, and win the game, or proceed as normal.
 *   There is no time limit on the power pellet, so the level acts as a sort of "free play" maze. Killing the ghosts is more fun in my opinion, though.
 * - A "Play Again" button is added to quit the game and then start a new one.
 * 
 * 
 * Areas of Concern: 
 * - The "Play Again" button will create duplicates of the MapSelection() method if pressed more than once
 *
 */

public class PacManGame {
	
	public static void main(String[]args) {
		
		new MapSelection();
	
		
	}

}
