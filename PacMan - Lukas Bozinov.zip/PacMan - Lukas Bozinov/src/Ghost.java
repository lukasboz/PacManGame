//this class creates the icons for the 3 ghosts

import javax.swing.ImageIcon;

@SuppressWarnings("serial")
public class Ghost extends Mover {

	//sets up the images that have the ghosts in them
	public static final ImageIcon[] IMAGE = { new ImageIcon("images/Ghost1.bmp"), new ImageIcon("images/Ghost2.bmp"),
			new ImageIcon("images/Ghost3.bmp"),

	};

	// constructor
	public Ghost(int ghostNum) {
		this.setIcon(IMAGE[ghostNum]);
	}

}
