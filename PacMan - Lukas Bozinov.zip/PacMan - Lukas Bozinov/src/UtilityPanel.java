//this class is a utility class used for displaying the score, win symbol, and a JButton to allow the user to play again

import javax.swing.*;

@SuppressWarnings("serial")
public class UtilityPanel extends JPanel{
	
	public static JLabel scoreLabel = new JLabel("Score: " + (String.valueOf(Board.score)));
	public static ImageIcon pacManWin = new ImageIcon("images/pacmanWin.bmp");
	public static JLabel winDisplay = new JLabel(pacManWin);
	
	public static JButton playAgainButton = new JButton();
	
	
	
	
}
