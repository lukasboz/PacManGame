//this is an abstract class used to help pac man move by keeping rack of the row he's in and the column  he's in, plus keep track of if pacman is dead or not

import javax.swing.JLabel;

@SuppressWarnings("serial")
public abstract class Mover extends JLabel {

	//declare row and column
	private int row;
	private int column;

	//declare dRow/dColumn/death
	private int dRow;
	private int dColumn;
	private boolean isDead;

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	public int getdRow() {
		return dRow;
	}

	public void setdRow(int dRow) {
		this.dRow = dRow;
	}

	public int getdColumn() {
		return dColumn;
	}

	public void setdColumn(int dColumn) {
		this.dColumn = dColumn;
	}

	public boolean isDead() {
		return isDead;
	}

	public void setDead(boolean isDead) {
		this.isDead = isDead;
	}

	//updates row and column based on dRow and dColumn
	public void move() {
		row += dRow;
		column += dColumn;
	}

	//set the direction that pacman is going to go
	public void setDirection(int direction) {
		dRow = 0;
		dColumn = 0;
		if (direction == 0) { 
			dColumn = -1;
		} // left
		else if (direction == 1) {
			dRow = -1;
		} // up
		else if (direction == 2) {
			dColumn = 1;
		} // right
		else if (direction == 3) {
			dRow = 1;
		} // down
	}

	//get the direction that pacman is going
	public int getDirection() {
		if (dRow == 0 && dColumn == -1) {
			return 0;
		} else if (dRow == -1 && dColumn == 0) {
			return 1;
		} else if (dRow == 0 && dColumn == 1) {
			return 2;
		} else {
			return 3;
		}
	}

	public int getNextRow() {
		return row + dRow;
	}

	public int getNextColumn() {
		return column + dColumn;
	}

}
