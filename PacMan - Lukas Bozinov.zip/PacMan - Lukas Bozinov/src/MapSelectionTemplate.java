//this class is a template class for mapSelection that simply has a getter and setter for the map choice of the user in MapSelection.java

public class MapSelectionTemplate {
	
	private String mapChoice;
	
	public String getMapChoice() {
		return mapChoice;
	}

	public void setMapChoice(String index) {
		this.mapChoice = index;
	}

}
