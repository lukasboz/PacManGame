//this class shows a screen to help the user of the program pick a map to play on, as well as take them to the actual pac man game

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class MapSelection extends JFrame implements ActionListener {

	static MapSelectionTemplate template = new MapSelectionTemplate(); //run the template class for this class

	private JPanel mapSelectionPanel = new JPanel(); //create a new panel

	private JLabel mapSelectionLabel = new JLabel(); //new label

	private JButton confirm = new JButton(); //create the confirmation button

	private JRadioButton[] mapChoiceArray = new JRadioButton[5]; //create the radio button array

	private ButtonGroup mapButtonGroup = new ButtonGroup(); //create the button group

	static String mapChoice; //create a static string to move to other methods like board()

	//run other methods in the class
	public MapSelection() {
		MapSelectionSetup();
		MapSelectionDisplay();
	}

	public void MapSelectionSetup() {

		// set the boundaries of the entire map selection panel
		mapSelectionPanel.setBounds(50, 70, 800, 600);
		mapSelectionPanel.setLayout(null); // use default flowLayout

		mapSelectionPanel.setBackground(Color.white); // set the background of the bordered panel to white

		// set the boundaries of the title
		mapSelectionLabel.setBounds(700, 20, 400, 100);
		mapSelectionPanel.add(mapSelectionLabel); // make the title visible on top of the panel

		Image icon = Toolkit.getDefaultToolkit().getImage("images/pacManIcon.png"); //set the image of the window icon
		setIconImage(icon);

		setupRadioButton(); // sets up the radio button

		confirm.setBounds(100, 400, 400, 200);// declare where the confirmation button will go
		confirm.setBackground(Color.green); //set the button's colour to green
		mapSelectionPanel.add(confirm);

		confirm.setText("Confirm Map Choice");// declare the text that will go on the confirmation button
		confirm.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		confirm.addActionListener(this);// make the button clickable
		
		setDefaultCloseOperation(MapSelection.EXIT_ON_CLOSE);

	}

	public void MapSelectionDisplay() {
		setSize(600, 800);//set size of window
		setTitle("Map Selection"); //set title of the window

		add(mapSelectionPanel); //add panel to frame

		setVisible(true); //make it visible
	}

	@Override
	public void actionPerformed(ActionEvent event) {

		for (int index = 0; index < mapChoiceArray.length; index++) {

			//for every radio button there is a map attached that will open 
			//when its respective option is chosen
			if (event.getSource() == mapChoiceArray[index]) {
				if (index == 0) {
					mapChoice = ("maze.txt");

				} else if (index == 1) {
					mapChoice = ("mazeTwo.txt");

				} else if (index == 2) {
					mapChoice = ("mazeThree.txt");
				} else if (index == 3) {
					mapChoice = ("mazeFour.txt");
				} else if (index == 4) {
					mapChoice = ("mazeFive.txt");
				}
			}
		}
		
		//load the map once the confirm button is clicked
		if (event.getSource() == confirm) {
			dispose();
			new PacManGUI();
		}
	}

	public void setupRadioButton() {

		JLabel choiceLabel = new JLabel(); //create the JLabel that has a prompt within it

		choiceLabel.setBounds(205, 20, 200, 200); //set where the label is going to be
		choiceLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 18)); // set the font, font style and font size
		mapSelectionPanel.add(choiceLabel); //add the label to the panel
		choiceLabel.setText("Pick a map! Any map!"); //set the text of the Label

		//set up all the options of buttons to click
		mapChoiceArray[0] = new JRadioButton("Original");
		mapChoiceArray[0].setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		
		mapChoiceArray[1] = new JRadioButton("Kill one Ghost to Win! (Special Mode)");
		mapChoiceArray[1].setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		
		mapChoiceArray[2] = new JRadioButton("Rows and Funnels");
		mapChoiceArray[2].setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		
		mapChoiceArray[3] = new JRadioButton("The Ultimate Challenge");
		mapChoiceArray[3].setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		
		mapChoiceArray[4] = new JRadioButton("Heavily Guarded Cherry Compound");
		mapChoiceArray[4].setFont(new Font("Comic Sans MS", Font.BOLD, 16));

		// actually prints the radio buttons that the user will choose from
		for (int index = 0; index < mapChoiceArray.length; index++) {

			mapButtonGroup.add(mapChoiceArray[index]);

			mapChoiceArray[index].setBounds(150, 150 + index * 25, 400, 25); //set where the array of buttons will appear

			mapSelectionPanel.add(mapChoiceArray[index]);

			for (int index1 = 0; index1 <= 4; index1++) {
				mapChoiceArray[index1].setBackground(Color.white); //set the background colour of every radio button to be white
			}

			mapChoiceArray[index].addActionListener(this); // make each button clickable

		}
	}

}
