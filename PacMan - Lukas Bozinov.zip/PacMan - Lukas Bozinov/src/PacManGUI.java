import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

@SuppressWarnings("serial")
public class PacManGUI extends JFrame implements ActionListener {

	// creates the board
	private Board board = new Board();

	// class name
	public PacManGUI() {

		// set size of the window
		setSize(625, 800);
		setTitle("Lukas - The Return of Pac-Man");
		setBackground(Color.BLACK);

		// set the icon for the window
		Image icon = Toolkit.getDefaultToolkit().getImage("images/pacManIcon.png");
		setIconImage(icon);

		// terminate the program when the "x" button is clicked
		setDefaultCloseOperation(PacManGUI.EXIT_ON_CLOSE);

		// set the layout of the utility panel to flowLayout so it doesn't mess with the
		// gridLayout of board.java
		setLayout(null);
		UtilityPanel.scoreLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 24)); // set font size/color/other
																					// modifiers
		getContentPane().setBackground(Color.BLACK); // set the background of the entire panel to black
		UtilityPanel.scoreLabel.setForeground(Color.WHITE);// set the text colour of the score to white
		UtilityPanel.scoreLabel.setBounds(100, 600, 300, 100);// set where the label will appear

		// setup button that asks to play again
		UtilityPanel.playAgainButton.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		UtilityPanel.playAgainButton.setText("Play Again?"); // set text of the button
		UtilityPanel.playAgainButton.setBackground(Color.GREEN); // set background
		UtilityPanel.playAgainButton.setForeground(Color.BLACK);// set foreground
		UtilityPanel.playAgainButton.setBounds(300, 600, 300, 100);// set boundaries
		UtilityPanel.playAgainButton.addActionListener(this);
		UtilityPanel.playAgainButton.setFocusable(false); // make sure play again button doesn't interfere

		//add the play again button and score label to the utility panel
		add(UtilityPanel.playAgainButton);
		add(UtilityPanel.scoreLabel);

		setVisible(true);

		// set up a listener that checks from keys being pressed/released/typed
		addKeyListener(board);
		add(board);

		// set the window to be visible
		setVisible(true);

	}

	//when the play again button is clicked, the program ends then starts again
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == UtilityPanel.playAgainButton) {
			System.out.println("User has chosen to play pac man again."); //this line is for the console to acknowledge the JButton was clicked
			dispose();//get rid of the current frame
			new MapSelection();//start the program over
		}

	}

}