import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;

@SuppressWarnings("serial")
public class Board extends JPanel implements KeyListener, ActionListener {

	// timers
	private Timer gameTimer = new Timer(250, this);
	private Timer animateTimer = new Timer(50, this);

	// image icons
	private static final ImageIcon WALL = new ImageIcon("images/wall.png");
	private static final ImageIcon FOOD = new ImageIcon("images/StdFood.bmp");
	private static final ImageIcon BLANK = new ImageIcon("images/Black.bmp");
	private static final ImageIcon DOOR = new ImageIcon("images/Black.bmp");
	private static final ImageIcon SKULL = new ImageIcon("images/Skull.bmp");
	private static final ImageIcon FRUIT = new ImageIcon("images/Cherry.bmp");
	private static final ImageIcon POWER = new ImageIcon("images/powerPellet.png");
	private static final ImageIcon CHECKMARK = new ImageIcon("images/checkmark.png");
	

	// create characters, map, and collectibles
	private char[][] maze = new char[25][27];

	private JLabel[][] cell = new JLabel[25][27]; //create the cells of the 2d array as a jlabel

	private PacMan pacMan; // create pacman

	private Ghost[] ghost = new Ghost[3]; // create the 3 ghosts

	private int pellets = 0; // create a pellets variable

	private int powerPellets = 0;// keep track of the amount of power pellets

	public static int score = 0; // create a score variable

	private int pStep = 0; // what stage of animation pacman is in

	// board class
	public Board() {

		// setup a new grid layout
		setLayout(new GridLayout(25, 27));
		setBackground(Color.BLACK);
		setBounds(0, 0, 600, 600);

		// create pac man
		pacMan = new PacMan();

		// create the 3 ghosts
		ghost[0] = new Ghost(0);
		ghost[1] = new Ghost(1);
		ghost[2] = new Ghost(2);

		// run the loadBoard method and play the start up sound when the window opens

		loadBoard();

	}

	private void loadBoard() {

		playStartSound(); //play the starting noise

		// keep track of what row we're on while reading in the .txt file
		int row = 0;

		// create a scanner to read in the .txt file
		Scanner input;

		// try{} replaces the use of only a while loop with a {}catch just
		// in case the .txt file for the maze is not found
		try {
			try {

				System.out.println(MapSelection.mapChoice); // line for debugging

				// read in the .txt file that holds the maze
				input = new Scanner(new File(MapSelection.mapChoice));

				if (MapSelection.mapChoice == "mazeFour.txt") {
					gameTimer.setDelay(10); // make pacman and the ghosts faster
				}

				// continuously reads in the .txt file one line at a time and sorts
				// each letter into its respective categories
				while (input.hasNext()) {

					// reads in one line of text and breaks it down into a char array
					// for example, the first line of .txt has 27 X's so it reads in 27 X's
					maze[row] = input.nextLine().toCharArray();

					// draws the maze
					for (int column = 0; column < maze[row].length; column++) {
						cell[row][column] = new JLabel();

						if (maze[row][column] == 'W') {//set wall icon
							cell[row][column].setIcon(WALL);
						}

						else if (maze[row][column] == 'F') {//set pellet icon
							cell[row][column].setIcon(FOOD);

							pellets++;
						}

						else if (maze[row][column] == 'Q') {//set power pellet icon
							cell[row][column].setIcon(POWER);

						}

						else if (maze[row][column] == 'X') {//set out of bounds icon
							cell[row][column].setIcon(BLANK);
						}

						else if (maze[row][column] == 'D') {//set door icon
							cell[row][column].setIcon(DOOR);
						}

						else if (maze[row][column] == 'C') {//set cherry icon
							cell[row][column].setIcon(FRUIT);
						}

						else if (maze[row][column] == 'P') {//set pacman icon
							cell[row][column].setIcon(pacMan.getIcon());

							//setup pacman
							pacMan.setRow(row);
							pacMan.setColumn(column);
							pacMan.setDirection(0); // starts facing left

						}

						else if (maze[row][column] == '0' || maze[row][column] == '1' || maze[row][column] == '2') {

							// convert the char to an equivalent integer
							int ghostNum = Character.getNumericValue(maze[row][column]);
							cell[row][column].setIcon(ghost[ghostNum].getIcon());

							//set position of ghosts
							ghost[ghostNum].setRow(row);
							ghost[ghostNum].setColumn(column);
						}

						add(cell[row][column]); //display the cell in the 2d array

					}
					row++; //increment the row
				}

				input.close();

				//displayed if the user doesn't pick a map
			} catch (NullPointerException error) {
				System.out.println("User did not pick a map option.");
			}

			//displayed if a file can't be found
		} catch (FileNotFoundException error) {
			System.out.println("File not found");
		}

	}

	private void performMove(Mover mover) {

		// "teleports" pac-man to the other side of the maze via the doorway
		// this one for the door on the left
		if (mover.getColumn() == 1) {
			mover.setColumn(24);
			cell[12][1].setIcon(DOOR);

			// this one for the door on the right
		} else if (mover.getColumn() == 25) {
			mover.setColumn(2);
			cell[12][25].setIcon(DOOR);
		}

		// starts an animation if the next row and next column aren't a wall
		if (maze[mover.getNextRow()][mover.getNextColumn()] != 'W') {
			if (mover == pacMan)
				animateTimer.start();

			else {
				// if the next "block" ahead is food then the icon is set to food
				if (maze[mover.getRow()][mover.getColumn()] == 'F') {
					cell[mover.getRow()][mover.getColumn()].setIcon(FOOD);
				}

				else
					// otherwise the block is left blank
					cell[mover.getRow()][mover.getColumn()].setIcon(BLANK);

				// pac man then proceeds to move
				mover.move();

				// if pacman hits a ghost, the ghost dies
				if(collided() && powerPellets == 1) {
					stopGameWithPowerPellet();
					//if pacman hits a ghost, he dies
				} else if (collided()) {
					death();
				}

				// otherwise, you move to the next block and begin an animation
				else
					cell[mover.getRow()][mover.getColumn()].setIcon(mover.getIcon());
			}
		}

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		// when the game timer starts, pacman begins to move and the ghosts move as well
		if (event.getSource() == gameTimer) {
			performMove(pacMan);
			moveGhosts();

			// otherwise, animations begin to play
		} else if (event.getSource() == animateTimer) {
			animatePacMan();
			pStep++;
			if (pStep == 3)
				pStep = 0;
		}
	}

	// remains to satisfy keyListener import
	@Override
	public void keyTyped(KeyEvent event) {

	}

	@Override
	public void keyPressed(KeyEvent key) {

		// starts the game if it's not already started
		if (gameTimer.isRunning() == false && pacMan.isDead() == false)
			gameTimer.start();

		// if pacman isn't dead, and all of the pellets haven't been eaten, the game
		// continues
		if (pacMan.isDead() == false && score != pellets) {

			// gets the inputs from the arrow keys
			int direction = key.getKeyCode() - 37;

			// tells pacman where to go when a key is pressed
			if (direction == 0 && maze[pacMan.getRow()][pacMan.getColumn() - 1] != 'W') // left
				pacMan.setDirection(0);

			else if (direction == 1 && maze[pacMan.getRow() - 1][pacMan.getColumn()] != 'W') // up
				pacMan.setDirection(1);

			else if (direction == 2 && maze[pacMan.getRow()][pacMan.getColumn() + 1] != 'W') // right
				pacMan.setDirection(2);

			else if (direction == 3 && maze[pacMan.getRow() + 1][pacMan.getColumn()] != 'W') // down
				pacMan.setDirection(3);
		}

	}

	// remains to satisfy keyListener import
	@Override
	public void keyReleased(KeyEvent event) {

	}

	private boolean collided() {
		// if the ghost and pacman are in the same column and row, pacman and the ghost
		// collide and pacman dies
		for (int ghostNum = 0; ghostNum < 3; ghostNum++) {
			if (ghost[ghostNum].getRow() == pacMan.getRow() && ghost[ghostNum].getColumn() == pacMan.getColumn()) {
				return true;
			}
		}
		// if they aren't in the same column and row, the game continues
		return false;
	}

	// sets what happens when pac man dies
	private void death() {
		pacMan.setDead(true); // death is set to true

		playDeathSound(); // play the death noise

		stopGame(); // the game stops

		cell[pacMan.getRow()][pacMan.getColumn()].setIcon(SKULL); // a skull is displayed wherever pac man died
	}
	
	// tells the program to stop the game if pac man is dead or if all the pellets
	// have been eaten
	private void stopGame() {
		pacMan.setDead(true);//redundancy just in case something goes wrong with the death() method
		if (pacMan.isDead()) {
			animateTimer.stop();
			gameTimer.stop();
		} 
	}
	
	//same as stopGame(), but with a different sound and a victory checkmark
	private void stopGameWithPowerPellet() {
		if (collided()) {
			stopGame();
			playWinSound(); //play the win sound
			
			cell[pacMan.getRow()][pacMan.getColumn()].setIcon(CHECKMARK); //set the icon where pacman hit the ghost as a checkmark
		} 
	}
	
	//check if the user has won but constantly checking score and pellets
	private boolean youWin() {
		if (score == pellets) {
			animateTimer.stop(); 
			gameTimer.stop();
			playWinSound();
			return true;
		} 
		return false;
	}
	
	private void moveGhosts() {
		for (Ghost ghostNum : ghost) {

			int direction; // direction placeholder

			// completely randomizes the direction of where the ghosts go
			do {
				direction = (int) (Math.random() * 4);
			} while (Math.abs(ghostNum.getDirection() - direction) == 2);

			ghostNum.setDirection(direction); // sets the direction to the randomized direction

			performMove(ghostNum); // tells the ghost to use the direction to move

		}
	}

	private void animatePacMan() {
		// if pac man is just opening his mouth, then the animation for his mouth
		// opening
		// plays and the animation timer is delayed so the user can see the mouth open
		if (pStep == 0) {
			cell[pacMan.getRow()][pacMan.getColumn()].setIcon(PacMan.IMAGE[pacMan.getDirection()][1]);

			animateTimer.setDelay(100);

			// pac man disappears for a brief moment to switch to his closed mouth form
		} else if (pStep == 1) {
			cell[pacMan.getRow()][pacMan.getColumn()].setIcon(BLANK);

			// pac man's closed mouth form is shown
		} else if (pStep == 2) {
			pacMan.move();

			// increase score if a pellet is eaten
			if (maze[pacMan.getRow()][pacMan.getColumn()] == 'F') {

				score++;
				UtilityPanel.scoreLabel.setText("Score: " + score);
				playPelletSound();

				youWin();
				maze[pacMan.getRow()][pacMan.getColumn()] = 'E'; // sets the block as empty once the pellet is eaten
				//if pacman hits a cherry, he speeds up a bit and plays the fruit pickup noise
			} else if (maze[pacMan.getRow()][pacMan.getColumn()] == 'C') {
				animateTimer.setDelay(90);

				playFruitSound(); //play fruit pickup sound

				maze[pacMan.getRow()][pacMan.getColumn()] = 'E'; //set it to empty afterward
				//if pacman hits a power pellet, the number of power pellets he picked up increases
			} else if (maze[pacMan.getRow()][pacMan.getColumn()] == 'Q') {
				powerPellets++;
				playFruitSound(); //play the fruit pickup sound
				

				maze[pacMan.getRow()][pacMan.getColumn()] = 'E'; //set it to empty afterward
			}

			animateTimer.stop();

			// check for death
			if (pacMan.isDead()) {
				cell[pacMan.getRow()][pacMan.getColumn()].setIcon(SKULL);

			} else
				cell[pacMan.getRow()][pacMan.getColumn()].setIcon(PacMan.IMAGE[pacMan.getDirection()][0]);

		}
	}

	// creates a clip the opens and starts whenever this method is called
	public void playStartSound() {
		try {
			// create a new input stream and grab the file from the sounds folder
			AudioInputStream audio = AudioSystem
					.getAudioInputStream(new File("sounds/GAMEBEGINNING.wav").getAbsoluteFile());
			Clip startGame = AudioSystem.getClip(); // create a clip called startGame and get the clip from the "audio

			startGame.open(audio);
			startGame.start(); // play the clip/sound
		} catch (Exception ex) { // print in console if the clip doesn't work for whatever reason
			System.out.println("Error with playing sound.");
			ex.printStackTrace();
		}
	}

	public void playPelletSound() {
		try {
			// create a new input stream and grab the file from the sounds folder
			AudioInputStream audio = AudioSystem.getAudioInputStream(new File("sounds/pacchomp.wav").getAbsoluteFile());
			Clip eat = AudioSystem.getClip(); // create a clip called startGame and get the clip from the "audio system"
												// that being the audio
			eat.open(audio);
			eat.start(); // play the clip/sound
		} catch (Exception ex) { // print in console if the clip doesn't work for whatever reason
			System.out.println("Error with playing sound.");
			ex.printStackTrace();
		}
	}

	public void playDeathSound() {
		try {
			// create a new input stream and grab the file from the sounds folder
			AudioInputStream audio = AudioSystem.getAudioInputStream(new File("sounds/killed.wav").getAbsoluteFile());
			Clip die = AudioSystem.getClip(); // create a clip called startGame and get the clip from the "audio system"
												// that being the audio
			die.open(audio);
			die.start(); // play the clip/sound
		} catch (Exception ex) { // print in console if the clip doesn't work for whatever reason
			System.out.println("Error with playing sound.");
			ex.printStackTrace();
		}
	}

	public void playFruitSound() {
		try {
			// create a new input stream and grab the file from the sounds folder
			AudioInputStream audio = AudioSystem.getAudioInputStream(new File("sounds/fruiteat.wav").getAbsoluteFile());
			Clip fruit = AudioSystem.getClip(); // create a clip called startGame and get the clip from the "audio
												// system" that being the audio
			fruit.open(audio);
			fruit.start(); // play the clip/sound
		} catch (Exception ex) { // print in console if the clip doesn't work for whatever reason
			System.out.println("Error with playing sound.");
			ex.printStackTrace();
		}
	}

	public void playWinSound() {
		try {
			// create a new input stream and grab the file from the sounds folder
			AudioInputStream audio = AudioSystem.getAudioInputStream(new File("sounds/interm.wav").getAbsoluteFile());
			Clip win = AudioSystem.getClip(); // create a clip called startGame and get the clip from the "audio system"
												// that being the audio
			win.open(audio);
			win.start(); // play the clip/sound
		} catch (Exception ex) { // print in console if the clip doesn't work for whatever reason
			System.out.println("Error with playing sound.");
			ex.printStackTrace();
		}
	}

}
